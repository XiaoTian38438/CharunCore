/*    */ import com.yanrong.server.plugin.Server;
/*    */ import com.yanrong.server.plugin.command.CommandSender;
/*    */ import com.yanrong.server.plugin.event.EventHandler;
/*    */ import com.yanrong.server.plugin.event.EventPriority;
/*    */ import com.yanrong.server.plugin.event.events.BlockBreakEvent;
/*    */ import com.yanrong.server.plugin.event.events.PlayerChatEvent;
/*    */ import com.yanrong.server.plugin.event.events.PlayerJoinEvent;
/*    */ import com.yanrong.server.plugin.event.events.PlayerMoveEvent;
/*    */ 
/*    */ public class TestPlugin extends Plugin implements EventListener {
/*    */   public void onEnable() {
/* 12 */     getLogger().info("测试插件已启用! dataFolder=" + getDataFolder().getPath());
/* 13 */     registerEvents(this);
/* 14 */     registerCommand("ping", "测试插件 ping 命令", (paramCommandSender, paramString, paramArrayOfString) -> { paramCommandSender.sendMessage("§aPong! 在线人数: " + Server.get().getOnlineCount()); return true; }new String[] { "tping" });
/*    */ 
/*    */ 
/*    */     
/* 18 */     getScheduler().runTaskTimer(ServerScheduler.ref(this), () -> {  }100L, 100L);
/*    */     
/* 20 */     saveDefaultConfig();
/* 21 */     getLogger().info("config 内容: " + String.valueOf(getConfig()));
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 26 */     getLogger().info("测试插件已禁用!");
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.NORMAL)
/*    */   public void onJoin(PlayerJoinEvent paramPlayerJoinEvent) {
/* 31 */     getLogger().info("事件: " + (paramPlayerJoinEvent.getPlayer()).username + " 加入, 消息=" + paramPlayerJoinEvent.getJoinMessage());
/*    */   }
/*    */   
/*    */   @EventHandler(ignoreCancelled = true)
/*    */   public void onChat(PlayerChatEvent paramPlayerChatEvent) {
/* 36 */     getLogger().info("事件: 聊天 " + (paramPlayerChatEvent.getPlayer()).username + ": " + paramPlayerChatEvent.getMessage());
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onBreak(BlockBreakEvent paramBlockBreakEvent) {
/* 41 */     getLogger().info("事件: 破坏方块 (" + paramBlockBreakEvent.getX() + "," + paramBlockBreakEvent.getY() + "," + paramBlockBreakEvent.getZ() + ") state=" + paramBlockBreakEvent.getBlockStateId());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onMove(PlayerMoveEvent paramPlayerMoveEvent) {}
/*    */ }


/* Location:              C:\Users\tian_\Desktop\mc-server-core1.21.11\plugins\TestPlugin.jar!\TestPlugin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */